
package Clases;


public class Ejemplar {
    private int idLibro;
    private boolean estado;
    private int cantidad ;

    public Ejemplar() {
    }

    public Ejemplar(int idLibro, boolean estado, int cantidad) {
        this.idLibro = idLibro;
        this.estado = estado;
        this.cantidad = cantidad;
    }

    public int getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
   
    @Override
    public String toString() {
        return "Ejemplar{" + "idLibro=" + idLibro + ", estado=" + estado + ", cantidad=" + cantidad + '}';
    }
    
}
